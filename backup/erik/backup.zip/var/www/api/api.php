<?php

 /* Should not be root, but a user account. */
$connection=mysqli_connect('127.0.0.1','root','bnss2015','api');
if (!$connection) {
	die('Could not connect to MySQL: ' . mysqli_connect_error()); 
}
$res = mysqli_query($connection, "select * from users"); // where name='$username'");
$users = 0;
$response = array();
while ($row = mysqli_fetch_assoc($res)){
	$response[] = $row;
}
print(json_encode($response));

mysqli_close($connection);


?>

