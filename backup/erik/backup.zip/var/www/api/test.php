<?php

echo "Hej <br> <center> det verkar fungera ju</center> ";
$response["hej"] = "nej";
print(json_encode($response));

?>
