#!/bin/bash 
cd /etc/pki
NAME=$( openssl x509 -in certs/$1.crt -text | sed -En 's/.*Subject.*CN=//p' )
PUB_KEY=$( cat user_pub_keys/$1_pub.pem )
#echo $NAME
#echo $PUB_KEY
if [ "$NAME" ] && [ "$PUB_KEY" ] ; then
	echo "INSERT INTO users (name, pub_key) VALUES ('"$NAME"', '"$PUB_KEY"')" | mysql --verbose -h "localhost" -u "root" "-pbnss2015" "api"
else
	echo "Error detected, not running mysql command"
fi
