#!/bin/bash
echo "Renewing Certificate Revocation List"
#cd /etc/pki
openssl ca -gencrl -config /etc/pki/conf/tls-ca.conf -keyfile /etc/pki/ca/tls-ca/private/tls-ca.key -out /etc/pki/crl/tls-ca.crl -crldays 1 -passin pass:'sweden is not so cold'
# Updating revocation list and making it available on server
openssl crl -in /etc/pki/crl/tls-ca.crl -out /var/www/ca/tls-ca.crl -outform der
service apache2 restart
echo ""
echo "-------------------------------------------"
echo "CRL reissued and all relevant files updated"
