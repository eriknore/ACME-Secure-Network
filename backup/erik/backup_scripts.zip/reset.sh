#!/bin/bash

# Remove users from mysql db
echo "DROP TABLE IF EXISTS users" | mysql -h "localhost" -u "root" "-pbnss2015" "api"
# Create new users in db
echo "CREATE TABLE IF NOT EXISTS users (
    id int NOT NULL AUTO_INCREMENT,
    name varchar(50) NOT NULL,
    pub_key blob,
    PRIMARY KEY(id)
)ENGINE=InnoDB;" | mysql -h "localhost" -u "root" "-pbnss2015" "api"
# remove old keys and generate new (makes it easier to try different fromats :)
rm /etc/pki/user_pub_keys/*
openssl rsa -in /etc/pki/certs/erik.key -pubout -outform PEM -out /etc/pki/user_pub_keys/erik_pub.pem -passin pass:'grodanboll'
openssl rsa -in /etc/pki/certs/adam.key -pubout -outform PEM -out /etc/pki/user_pub_keys/adam_pub.pem -passin pass:'correct'
#openssl rsa -in /etc/pki/certs/micke.key -pubout -outform PEM -out /etc/pki/user_pub_keys/micke_pub.pem
# add existing users
sh /etc/pki/scripts/test.sh erik
sh /etc/pki/scripts/test.sh adam
#sh /etc/pki/scripts/test.sh micke
