#!/bin/bash 
cd /etc/pki
PUB_KEY=$( cat user_pub_keys/$1_pub.pem )
echo $PUB_KEY
if [ "$PUB_KEY" ] ; then
	echo "DELETE FROM users WHERE pub_key = '"$PUB_KEY"'" | mysql -h "localhost" -u "root" "-pbnss2015" "api"
else
	echo "Error detected, not running mysql command"
fi
