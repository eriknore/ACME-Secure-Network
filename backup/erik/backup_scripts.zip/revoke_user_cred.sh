#!/bin/bash
if [ ! $# == 1 ]; then
    echo "ERROR:   usage    revoke_user_cred NAME_OF_USER"
    exit
fi
if [ ! -e /etc/pki/certs/$1.crt ]; then
    echo "ERROR:   User does not exist!"
    exit
fi

cd /etc/pki
openssl ca -config conf/tls-ca.conf -revoke certs/$1.crt \
-crl_reason affiliationChanged
openssl ca -gencrl -config conf/tls-ca.conf -out crl/tls-ca.crl -crldays 2
# Removing record from MySQL matching public key
echo "Removing record from MySQL..."
PUB_KEY=$( cat user_pub_keys/$1_pub.pem )
if [ "$PUB_KEY" ] ; then
        echo "DELETE FROM users WHERE pub_key = '"$PUB_KEY"'" | mysql -h "localhost" -u "root" "-pbnss2015" "api"
else
        echo "Error detected, not running mysql command"
fi
rm -f user_pub_keys/$1_pub.pem export_PKCS12/$1.p12
# Updating revocation list and making it available on server
openssl crl -in crl/tls-ca.crl -out /var/www/ca/tls-ca.crl -outform der
service apache2 restart
echo ""
echo "-------------------------------------------"
echo "User" $1 "has been revoked"

