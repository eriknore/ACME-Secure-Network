#!/bin/bash 
openssl x509 -in ca/tls-ca.crt -out ca/tls-ca.cer -outform der
openssl crl -in crl/tls-ca.crl -out crl/tls-ca.crl -outform pem
# Making certificates publicly available on server
openssl crl -in crl/tls-ca.crl -out /var/www/ca/tls-ca.crl -outform der
cp ca/tls-ca.cer /var/www/ca/tls-ca.cer
cp ca/tls-ca.crt /var/www/ca/tls-ca.crt
cp ca/root-ca.cer /var/www/ca/root-ca.cer
cp ca/root-ca.crt /var/www/ca/root-ca.crt
cp crl/root-ca.crl /var/www/ca/root-ca.crl
echo "-------------------------------------------"
echo "Main server credentials distributed"

