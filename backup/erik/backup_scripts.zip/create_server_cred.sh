#!/bin/bash
if [ ! $# == 1 ]; then
    echo "ERROR:   usage    create_server_cred NAME_OF_USER"
    exit
fi
if [ -e certs/$1.crt ]; then
    echo "ERROR:   User already exists"
    exit
fi

# SAN=DNS:... not working, will use common name in .conf
cd /etc/pki
SAN=DNS:172.31.212.103,DNS:acme.se,DNS:*.acme.se \
openssl req -new -config conf/server.conf -out certs/$1.csr \
-keyout certs/$1.key
openssl ca -config conf/tls-ca.conf -in certs/$1.csr \
-out certs/$1.crt -extensions server_ext
echo "-------------------------------------------"
echo "New server credentials generated, available at certs/"$1".crt"

